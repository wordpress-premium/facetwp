## FacetWP - Elementor integration

This add-on lets you display facets alongside various Elementor listing widgets.

[Read the setup instructions](https://facetwp.com/help-center/using-facetwp-with/elementor/)
