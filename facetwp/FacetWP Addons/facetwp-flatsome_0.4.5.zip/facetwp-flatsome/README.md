# facetwp-flatsome
FacetWP integration with the Flatsome theme
