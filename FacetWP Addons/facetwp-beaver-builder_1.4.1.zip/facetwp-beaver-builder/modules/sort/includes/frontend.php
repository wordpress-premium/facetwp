<?php

echo facetwp_display( 'sort' );