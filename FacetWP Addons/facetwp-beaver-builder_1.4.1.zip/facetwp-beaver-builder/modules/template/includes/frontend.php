<?php

echo facetwp_display( 'template', $settings->template );
