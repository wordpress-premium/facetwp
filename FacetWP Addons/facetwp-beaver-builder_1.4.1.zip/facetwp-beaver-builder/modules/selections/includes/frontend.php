<?php

echo facetwp_display( 'selections' );