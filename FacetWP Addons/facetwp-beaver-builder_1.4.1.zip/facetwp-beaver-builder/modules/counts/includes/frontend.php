<?php

echo facetwp_display( 'counts' );