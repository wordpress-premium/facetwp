<?php

echo facetwp_display( 'per_page' );